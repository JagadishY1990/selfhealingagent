
import docker, time, os
from datetime import datetime
from llama_cpp import Llama

# Config
RETRY_DELAY = 10
IMAGE_TAG = "myapp:latest"
DOCKERFILE_PATH = "."
MODEL_PATH = "models/mistral-7b-instruct-v0.2.Q4_0.gguf"

client = docker.from_env()
low_client = docker.APIClient(base_url='unix://var/run/docker.sock')
llm = Llama(model_path=MODEL_PATH, n_ctx=2048)

def log(msg):
    ts = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    print(f"{ts} {msg}")

def analyze_with_llm(build_log):
    prompt = (
        "You are an expert build assistant. Analyze this Docker build log "
        "and explain what went wrong:\n\n" + build_log
    )
    try:
        resp = llm(prompt, max_tokens=256, stop=["</s>"])
        return resp["choices"][0]["text"].strip()
    except Exception as e:
        return f"LLM ERROR: {e}"

def monitor_and_react():
    while True:
        log("Waiting for 'docker build' events...")
        for ev in low_client.events(decode=True):
            if ev.get("Type") == "image" and ev.get("Action") == "build":
                log("Detected a build event — attaching...")
                break

        try:
            build_stream = low_client.build(path=DOCKERFILE_PATH, tag=IMAGE_TAG, decode=True)
            lines = []
            failed = False
            for chunk in build_stream:
                if 'stream' in chunk:
                    line = chunk['stream']
                    lines.append(line)
                    print(line, end='')
                if 'errorDetail' in chunk:
                    failed = True
                    err = chunk['errorDetail']['message']
                    lines.append(err)
                    print(f"\n[ERROR] {err}")

            if failed:
                log("Build failed. Analyzing...")
                feedback = analyze_with_llm("".join(lines))
                log("AI Analysis:\n" + feedback)
                log(f"Retrying in {RETRY_DELAY}s…")
                time.sleep(RETRY_DELAY)
            else:
                log("✅ Build succeeded!")
                break

        except Exception as e:
            log(f"Agent error: {e}")
            time.sleep(RETRY_DELAY)

if __name__ == "__main__":
    os.makedirs("logs", exist_ok=True)
    monitor_and_react()
