
# AI Docker Build Agent

Monitors Docker builds, analyzes failures using a local LLM, and automatically retries.

## Setup

1. Clone repo:
   ```
   git clone https://github.com/<your-username>/ai-docker-agent.git
   cd ai-docker-agent
   ```

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Download a GGUF model into `models/`, for example:
   ```
   mkdir -p models
   wget -P models https://huggingface.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF/resolve/main/mistral-7b-instruct-v0.2.Q4_0.gguf
   ```

4. Run the agent:
   ```
   python agent.py
   ```

5. In another terminal, run your build:
   ```
   docker build -t myapp:latest .
   ```

The agent will:
- Detect the build start
- Stream logs
- Analyze failures via local LLM
- Retry after 10 seconds (default)

## Customization

- Change `RETRY_DELAY` or `IMAGE_TAG` in `agent.py`
- Add notification hooks (Slack, email)
- Dockerize this agent itself 🤖
